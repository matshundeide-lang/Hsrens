
document.addEventListener('DOMContentLoaded',()=>{
  const b=document.querySelector('.burger');
  const m=document.querySelector('.menu');
  if(b && m){ b.addEventListener('click',()=> m.classList.toggle('open')); }
});
