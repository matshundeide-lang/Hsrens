# HS Rens & Vedlikehold – statisk nettside

Enkel, rask og sikker statisk side klar for Netlify + GitHub. Innhold på norsk.

## Strukturen
- `index.html` – forside
- `tjenester/` – tjenester
- `om-oss/` – om oss
- `kontakt-oss/` – kontaktskjema (Netlify Forms)
- `varmepumperens/` – landingsside (fastpris 1399,-)
- `assets/` – CSS og JS
- `netlify.toml` – byggeoppsett og enkle headere
- `sitemap.xml`, `robots.txt`, `404.html`

## Deploy (GUI)
1. Last opp disse filene til en **ny GitHub-repo** (Public er ok).
2. På **Netlify**: New Site from Git → GitHub → velg repo → Deploy.
3. Under **Site settings → Domain management**: legg til `hsrens.no` og `www.hsrens.no`.
4. Netlify viser hvilke **DNS-poster** du må sette hos Webhuset. Legg dem inn der.
5. Aktiver **HTTPS** (Let’s Encrypt) i Netlify.
6. Under **Forms** i Netlify kan du skru på e-postvarsling for `kontakt`-skjemaet.

## Deploy (CLI – valgfritt)
```bash
npm i -g netlify-cli
netlify init   # velg GitHub repo
netlify deploy --prod
```
